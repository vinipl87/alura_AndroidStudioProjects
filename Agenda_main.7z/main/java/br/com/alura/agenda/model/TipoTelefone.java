package br.com.alura.agenda.model;

public enum TipoTelefone {
    FIXO, CELULAR
}