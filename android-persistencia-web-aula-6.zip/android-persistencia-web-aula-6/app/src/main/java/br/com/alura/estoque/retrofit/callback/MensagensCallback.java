package br.com.alura.estoque.retrofit.callback;

interface MensagensCallback {
    String MENSAGEM_ERRO_RESPOSTA_NAO_SUCEDIDA = "Resposta não sucedida";
    String MENSAGEM_ERRO_FALHA_COMUNICAO = "Falha de comunicação: ";
}
