package br.com.alura.financask.model

enum class Tipo {
    RECEITA, DESPESA
}