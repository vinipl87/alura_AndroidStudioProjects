package br.com.alura.technews.ui.activity

const val NOTICIA_ID_CHAVE = "noticiaId"