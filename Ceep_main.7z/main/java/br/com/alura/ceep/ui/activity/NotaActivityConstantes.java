package br.com.alura.ceep.ui.activity;

public interface NotaActivityConstantes {
    String CHAVE_NOTA = "nota";
    String CHAVE_POSICAO = "posicao";
    int CODIGO_REQUISICAO_INSERE_NOTA = 1;
    int CODIGO_REQUISICAO_ALTERA_NOTA = 2;
    int POSICAO_INVALIDA = -1;
}
