package br.com.alura.aluraesporte.model

class Usuario(val email: String, val senha: String = "")