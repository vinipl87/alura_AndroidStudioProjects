package br.com.alura.meetups.repository

class Resultado<T>(
    val dado: T? = null,
    val erro: String? = null,
)

