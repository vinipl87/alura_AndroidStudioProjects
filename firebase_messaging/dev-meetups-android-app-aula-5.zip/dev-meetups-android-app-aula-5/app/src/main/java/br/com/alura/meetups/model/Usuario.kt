package br.com.alura.meetups.model

class Usuario(val email: String?)